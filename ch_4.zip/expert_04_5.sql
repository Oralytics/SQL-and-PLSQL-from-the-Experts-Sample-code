set lines 120
set pages 999
set tab off
set echo on

select dt
      ,rain
  from weather
 order by dt
/

select dt
      ,rain
      ,trend
  from weather
  match_recognize (
  order by dt
  measures classifier() as trend
  all rows per match
  pattern (better* worse* same*)
  define better as better.rain < prev (rain)
        ,worse  as worse.rain > prev (rain)
        ,same   as same.rain = prev (rain)
  )
/

select dt
      ,rain
      ,case
       when rain < lag (rain) over (order by dt)
       then 'Better'
       when rain > lag (rain) over (order by dt)
       then 'Worse'
       when rain = lag (rain) over (order by dt)
       then 'Same'
       end trend
from weather
/


select *
  from weather
 match_recognize (
   order by dt
   measures
    first (wet.dt) as first_wetday
    ,dry.dt as dryday
    ,last (wet.dt) as last_wetday
    one row per match
   pattern (wet dry{2,} wet*)
   define wet as wet.rain > 10
         ,dry as dry.rain <= 10
 )
 /
