select term
      ,regexp_replace (term, '[^[:digit:]]') num
  from payment_terms
/


select term
      ,regexp_replace (term, '[^[:digit:].]') num
  from payment_terms
/


select term
  from payment_terms
  order by to_number (
            regexp_replace (term, '[^[:digit:].]')
           ,'999G999G999D999999'
           ,'NLS_NUMERIC_CHARACTERS=''.,'''
           )
/

select term
  from payment_terms
 order by sort_column
/
