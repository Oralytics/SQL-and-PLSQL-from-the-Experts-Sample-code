/*
When using SQL*Plus the settings below will format the output
*/
set lines 200
set pages 9999
col name format a28
col phone format a25
col phone2 format a25

select id
      ,name
      ,regexp_substr (description, '...-...-....') phone
  from theme_parks
/


select id
      ,name
      ,regexp_substr (description, '[0-9][0-9][0-9]-[0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]') phone
  from theme_parks
/


select id
      ,name
      ,regexp_substr (description, '[0-9]{3}-[0-9]{3}-[0-9]{4}') phone
  from theme_parks
/


select id
      ,name
      ,regexp_substr (description, '[0-9]{3}(-| )[0-9]{3}(-| )[0-9]{4}') phone
  from theme_parks
/


select id
      ,name
      ,regexp_substr (description, '[0-9]{3}(-| |\.)[0-9]{3}(-| |\.)[0-9]{4}') phone
  from theme_parks
/

select id
      ,name
      ,regexp_replace (
               regexp_substr (description
                       ,'([0-9]{3})(-| |\.)([0-9]{3})(-| |\.)([0-9]{4})'
                       )
               ,'([0-9]{3})(-| |\.)([0-9]{3})(-| |\.)([0-9]{4})'
               ,'\1-\3-\5'
               )   phone
  from theme_parks
/


pause To find the second telephone number, not discussed in the chapter

select id
      ,name
      ,regexp_substr (description, '[0-9]{3}(-| |\.)[0-9]{3}(-| |\.)[0-9]{4}') phone
      ,regexp_substr (description, '[0-9]{3}(-| |\.)[0-9]{3}(-| |\.)[0-9]{4}', 1, 2) phone2
  from theme_parks
/

pause Also find the telephone number which is listed as a name in this example

select id
      ,name
      ,regexp_substr (description, '\(?[[:digit:]]{3}\)?(-| |\.)([[:digit:]]{3}|[[:alpha:]]{3})(-| |\.)([[:digit:]]{4}|[[:alpha:]]{4})') phone
      ,regexp_substr (description, '\(?([[:digit:]]{3}|[[:digit:]]{1}[[:alpha:]]{2})\)?(-| |\.)([[:digit:]]{3}|[[:alpha:]]{3})(-| |\.)([[:digit:]]{4}|[[:alpha:]]{4})', 1, 2) phone2
  from theme_parks
/

pause You get a lot of false positives when using the character class alnum

select id
      ,name
      ,regexp_substr (description, '\(?[[:alnum:]]{3}\)?(-| |\.)[[:alnum:]]{3}(-| |\.)[[:alnum:]]{4}') phone
      ,regexp_substr (description, '\(?[[:alnum:]]{3}\)?(-| |\.)[[:alnum:]]{3}(-| |\.)[[:alnum:]]{4}', 1, 2) phone
  from theme_parks
/

pause Including the colon and a space yields better results
select id
      ,name
      ,regexp_substr (description, ': \(?[[:alnum:]]{3}\)?(-| |\.)[[:alnum:]]{3}(-| |\.)[[:alnum:]]{4}') phone
      ,regexp_substr (description, ': \(?[[:alnum:]]{3}\)?(-| |\.)[[:alnum:]]{3}(-| |\.)[[:alnum:]]{4}', 1, 2) phone
  from theme_parks
/
