set tab off
set pages 999
set lines 120
set echo on

select name
  from t
 where name = 'BLAKE'
/
select name
  from t
 where name = 'BL_KE'
/
select name
  from t
 where name = 'BL%KE'
/

select name
  from t
 where name like 'BLAKE'
/

select name
  from t
 where name like 'BL_KE'
/
select name
  from t
 where name like 'BL%KE'
/

select name
  from t
 where name like 'B%'
/
select name
  from t
 where name like '%B'
/

select name
  from t
 where name like '%B%'
/
select name
  from t
 where name like '%B%\_K%' ESCAPE '\'
/
select name
  from t
 where name like 'BL\_KE' ESCAPE '\'
/
select name
  from t
 where name like 'BL"_KE' ESCAPE '"'
/


select *
  from t
 where regexp_like (name, 'BL.KE')
/

select *
  from t
 where regexp_like (name, '^BL.KE$')
/

select *
  from t
 where regexp_like (name, 'BL(A|O)KE')
/
