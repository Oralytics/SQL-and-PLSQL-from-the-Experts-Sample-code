set echo on
set lines 120
set pages 999
set tab off

with t as
(select 'Steven' as name from dual union all
 select 'Stephen' from dual union all
 select 'Stephven' from dual union all
 select 'Stevphen' from dual
)
select name
  from t
 where regexp_like (name, 'Ste(v|ph)en')
/
drop table test purge
/

create table test
(str varchar2(500))
/

insert into test
values ('ABC,DEF,GHI,JKL,MNO')
/

commit;

select *
  from test
/
select regexp_substr (str, '[^,]+') split
  from test
/

select regexp_substr (str, '[^,]+', 1, 2) split
  from test
/
select regexp_substr (str, '[^,]+', 1, rownum) split
  from test
 connect by level <= 5
/


select regexp_substr (str, '[^,]+', 1, rownum) split
  from test
  connect by level <= regexp_count (str, '[^,]+')
/

insert into test
values ('123,456,789')
/
commit
/

select regexp_substr (str, '[^,]+', 1, rownum) split
  from test
  connect by level <= regexp_count (str, '[^,]+')
/
select regexp_substr (str, '[^,]+', 1, rownum) split
      , regexp_count (str, '[^,]+')
  from test
  connect by level <= regexp_count (str, '[^,]+')
/

select str
      ,regexp_substr (str, '[^,]+', 1, rn) split
 from test
 cross
 join (select rownum rn
         from (select max (length (regexp_replace (str, '[^,]+'))) + 1 mx
                 from test
              )
      connect by level <= mx
      )
where regexp_substr (str, '[^,]+', 1, rn) is not null
/
select regexp_substr (str, '[^,]+', 1, rn) split
 from test
 cross
 join (select rownum rn
         from (select max (regexp_count (str, '[^,]+')) mx
                 from test
              )
      connect by level <= mx
      )
where regexp_substr (str, '[^,]+', 1, rn) is not null
/

select split
  from test
      ,lateral (select regexp_substr (str, '[^,]+', 1, rownum) split
                  from dual
               connect by level <= regexp_count(str, ',') + 1)
/

select split
  from test
  left outer
  join lateral (select regexp_substr (str, '[^,]+', 1, rownum) split
                  from dual
               connect by level <= regexp_count(str, ',') + 1)
    on 1=1
/
