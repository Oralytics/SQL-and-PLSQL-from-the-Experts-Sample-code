set define off

drop table t purge
/

create table t
(name varchar2(25))
/

insert into t (name) values ('BLAKE');
insert into t (name) values ('BLOKE');
insert into t (name) values ('BLEAKE');
insert into t (name) values ('BLKE');
insert into t (name) values ('JAKESBLAKE');
insert into t (name) values ('BLAKESJAKE');
insert into t (name) values ('BL_KE');
insert into t (name) values ('BL%KE');
commit
/


drop table theme_parks purge
/

create table theme_parks
(id number
,name varchar2(50)
,description clob
);

declare
   c clob;
begin
   c :=    q'[Aquatica Orlando brings the best of an aquarium, zoo, water park and amusement park together into one experience. With 38 slides, 84,000 acres of white sand beach and private cabanas for rent, you can easily spend the entire day enjoying the Florida sun with your family. Don't miss the Dolphin Plunge, a clear tube water slide that takes you through the Commerson's dolphin habitat.
   5800 Water Play Way
Orlando, FL 32821
Region: Orlando
Phone: 407-351-3600
Toll-Free: 800-327-2424]';
insert into theme_parks
   (id, name, description)
values
   (1, 'Aquatica Orlando', c);
end;
/

declare
   c clob;
begin
   c :=    q'[What started as a showcase for the latest in innovation has transformed into one of Orlando's largest theme parks, Epcot. It's hard to believe how much Disney managed to pack into these 305 acres; you'll find an aquarium, 1.3-mile promenade around the World Showcase Lagoon, 11 pavilions celebrating nations of the world and numerous attractions, like the iconic Spaceship Earth.
   200 Epcot Center Drive
Lake Buena Vista, FL 32821
Region: Disney Area
Phone: 407 939 5277
Toll-Free: 800 647 7900]';
insert into theme_parks
   (id, name, description)
values
   (2, 'Epcot', c);
end;
/


declare
   c clob;
begin
   c :=    q'[Universal Studios Islands of Adventure bring some of your favorite movie experiences to life. Wander through the world of Hogwarts at the Wizarding World of Harry Potter, take a thrilling raft ride past dinosaurs on the Jurassic Park River Adventure, meet your favorite children's book characters at Seuss Landing, get wet in Toon Lagoon or fly through the air on the Marvel Super Hero Island attractions.
   6000 Universal Blvd.
Orlando, FL 32819
Region: Orlando
Phone: (407) 363-8000
Toll-Free: 1-800-407-4275]';
insert into theme_parks
   (id, name, description)
values
   (3, 'Islands of Adventure', c);
end;
/



declare
   c clob;
begin
   c :=    q'[LEGOLAND Florida, the largest LEGOLAND park in the world, features 50 rides, shows and attractions spread out over the LEGO-strewn 150-acres. If you're traveling with younger kids, LEGOLAND makes a great choice since its designed for kids between the ages of 2 and 12. Be sure to stop by the Big Shop to bring some of the LEGO action home.
One LEGOLAND Way
Winter Haven, FL 33884
Region: Polk County
Phone: 877-350-5346
Toll-Free: 877-350-LEGO]';
insert into theme_parks
   (id, name, description)
values
   (4, 'LEGOLAND Florida', c);
end;
/

declare
   c clob;
begin
   c :=    q'[Disney's Magic Kingdom, the sister of Disneyland in California, opened in 1971 with the 189-foot Cinderella's Castle jutting up from the center. The park's six themed areas -- Main Street USA, Adventureland, Frontierland, Liberty Square, Tomorrowland and Fantasyland -- are home to classic Disney favorites, like It's A Small World and the Jungle Cruise, as well as some new offerings.
   1180 Seven Seas Drive
Lake Buena Vista, FL 32830
Region: Disney Area
Phone: 407.939.5277
Toll-Free: 800.647.7900]';
insert into theme_parks
   (id, name, description)
values
   (5, 'Disney''s Magic Kingdom', c);
end;
/




declare
   c clob;
begin
   c :=    q'[With guest access restricted to 1,300 per day, Discovery Cove feels more like an exclusive resort than a theme park. Without crowds to worry about, you'll get to enjoy up-close animal encounters with dolphins, sting rays, tropical fish, sea otters and exotic birds. It's all-inclusive too, so you won't have to worry about food, towels or snorkeling equipment.
   6000 Discovery Cove Way
Orlando, FL 32821
Region: Orlando
Phone: 877-557-7404
Toll-Free: 4DI-SCO-VERY]';
insert into theme_parks
   (id, name, description)
values
   (6, 'Discovery Cove', c);
end;
/





declare
   c clob;
begin
   c :=    q'[Universal Studios Florida, the original park of Universal Studios Resort, brings pop culture to life on its 107 acres of Orlando real estate. Relive classics like E.T. and The Terminator or catch up with the characters of newer releases, like Despicable Me and Shrek.
   6000 Universal Blvd.
Orlando, FL 32819
Region: Orlando
Phone: 407-363-8000
Toll-Free: 800-407-4275]';
insert into theme_parks
   (id, name, description)
values
   (7, 'Universal Studios Florida', c);
end;
/



declare
   c clob;
begin
   c :=    q'[At the Animal Kingdom, Disney elevates the concept of a zoological park to something completely new. Here you can take a safari ride through the wilds of Africa -- complete with real animals, raft down the Amazon or ride a runaway train through Mount Everest. The park is home to about 1,500 animals representing 250 species.
   2901 Osceola Parkway
Lake Buena Vista, FL 32830
Region: Disney Area
Phone: 407-939-5277
Toll-Free: 800-647-7900]';
insert into theme_parks
   (id, name, description)
values
   (8, 'Disney''s Animal Kingdom', c);
end;
/



declare
   c clob;
begin
   c :=    q'[At SeaWorld Orlando, you and your family can meet Shamu, the world's most famous killer whale. After you've observed all the underwater critters living at the park, get your heart racing on SeaWorld's rides and roller coasters, catch a comedy show featuring sea lions and otters or grab a bite at Sharks Underwater Grill.
   7007 SeaWorld Dr.
Orlando, FL 32821
Region: Orlando
Phone: 888-800-5447
Toll-Free: 800-327-2424]';
insert into theme_parks
   (id, name, description)
values
   (9, 'SeaWorld Orlando', c);
end;
/


declare
   c clob;
begin
   c :=    q'[Go to the movies with Disney at Hollywood Studios, a theme park that takes you inside the world of show business with live stunt shows, animation galleries, a backlot tour and plenty of live shows, rides and attractions. Thrill seekers should be sure to take the plunge down the Twilight Zone Tower of Terror.
   351 S. Studio Dr
Lake Buena Vista, FL 32830
Region: Disney Area
Phone: 407-939-5277
Toll-Free: 800-647-7900]';
insert into theme_parks
   (id, name, description)
values
   (10, 'Disney''s Hollywood Studios', c);
end;
/

commit
/

-- Match_Recognize clause
drop table weather purge
/

create table weather
(dt   date  not null
,rain number not null
);



insert into weather values (to_date ('01-AUG-2016', 'dd-MON-yyyy'), 14);
insert into weather values (to_date ('02-AUG-2016', 'dd-MON-yyyy'),  0);
insert into weather values (to_date ('03-AUG-2016', 'dd-MON-yyyy'), 19);
insert into weather values (to_date ('04-AUG-2016', 'dd-MON-yyyy'),  6);
insert into weather values (to_date ('05-AUG-2016', 'dd-MON-yyyy'), 20);
insert into weather values (to_date ('06-AUG-2016', 'dd-MON-yyyy'),  1);
insert into weather values (to_date ('07-AUG-2016', 'dd-MON-yyyy'), 17);
insert into weather values (to_date ('08-AUG-2016', 'dd-MON-yyyy'), 17);
insert into weather values (to_date ('09-AUG-2016', 'dd-MON-yyyy'), 14);
insert into weather values (to_date ('10-AUG-2016', 'dd-MON-yyyy'), 18);
insert into weather values (to_date ('11-AUG-2016', 'dd-MON-yyyy'),  9);
insert into weather values (to_date ('12-AUG-2016', 'dd-MON-yyyy'),  4);
insert into weather values (to_date ('13-AUG-2016', 'dd-MON-yyyy'), 17);
insert into weather values (to_date ('14-AUG-2016', 'dd-MON-yyyy'), 16);
insert into weather values (to_date ('15-AUG-2016', 'dd-MON-yyyy'),  5);
insert into weather values (to_date ('16-AUG-2016', 'dd-MON-yyyy'),  5);
insert into weather values (to_date ('17-AUG-2016', 'dd-MON-yyyy'), 10);
insert into weather values (to_date ('18-AUG-2016', 'dd-MON-yyyy'),  5);
insert into weather values (to_date ('19-AUG-2016', 'dd-MON-yyyy'), 14);
insert into weather values (to_date ('20-AUG-2016', 'dd-MON-yyyy'), 19);
insert into weather values (to_date ('21-AUG-2016', 'dd-MON-yyyy'), 15);
insert into weather values (to_date ('22-AUG-2016', 'dd-MON-yyyy'), 12);
insert into weather values (to_date ('23-AUG-2016', 'dd-MON-yyyy'), 18);
insert into weather values (to_date ('24-AUG-2016', 'dd-MON-yyyy'),  2);
insert into weather values (to_date ('25-AUG-2016', 'dd-MON-yyyy'),  5);
insert into weather values (to_date ('26-AUG-2016', 'dd-MON-yyyy'),  4);
insert into weather values (to_date ('27-AUG-2016', 'dd-MON-yyyy'), 15);
insert into weather values (to_date ('28-AUG-2016', 'dd-MON-yyyy'),  7);
insert into weather values (to_date ('29-AUG-2016', 'dd-MON-yyyy'),  0);
insert into weather values (to_date ('30-AUG-2016', 'dd-MON-yyyy'), 12);
insert into weather values (to_date ('31-AUG-2016', 'dd-MON-yyyy'), 11);

commit;

drop table payment_terms purge
/

create table payment_terms
(term varchar2 (15)
)
/

insert into payment_terms
select 'Period 0.5 days' term from dual union all
select 'Period 1.0 days' term from dual union all
select 'Period 1.5 days' term from dual union all
select 'Period 10 days' term from dual union all
select 'Period 2.0 days' term from dual union all
select 'Period 2.5 days' term from dual union all
select 'Period 3.0 days' term from dual union all
select 'Period 3.5 days' term from dual union all
select 'Period 4.0 days' term from dual union all
select 'Period 4.5 days' term from dual union all
select 'Period 5.0 days' term from dual union all
select 'Period 5.5 days' term from dual union all
select 'Period 6.0 days' term from dual union all
select 'Period 6.5 days' term from dual union all
select 'Period 7.0 days' term from dual union all
select 'Period 7.5 days' term from dual union all
select 'Period 8.0 days' term from dual union all
select 'Period 8.5 days' term from dual union all
select 'Period 9.0 days' term from dual union all
select 'Period 9.5 days' term from dual
/
commit
/

alter table payment_terms
add sort_column generated always
as (to_number (
          regexp_replace (term, '[^[:digit:].]')
         ,'999G999G999D999999'
         ,'NLS_NUMERIC_CHARACTERS=''.,'''
         ))
/

set define on
