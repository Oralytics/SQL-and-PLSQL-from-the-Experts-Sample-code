create or replace
procedure show_dept_emps (p_deptno    in number
                         ,p_show_emps in boolean := true
                         )
is
   l_rc sys_refcursor;
begin
   open l_rc
   for
   select deptno
         ,dname
         ,loc
     from dept
    where deptno = p_deptno;
   dbms_sql.return_result(l_rc);
   if p_show_emps
   then
      open l_rc
      for
      select empno
            ,ename
            ,job
            ,sal
        from emp
       where deptno = p_deptno
      ;
      dbms_sql.return_result (l_rc);
   end if;
end show_dept_emps;
/


set tab off
set pages 999
set lines 120

begin
   show_dept_emps (p_deptno => 10);
end;
/

begin
   show_dept_emps (p_deptno    => 10
                  ,p_show_emps => false
                  );
end;
/
