CREATE OR REPLACE PROCEDURE show_emps (
   department_id_in IN
   emp.deptno%TYPE)
IS
   l_cursor   SYS_REFCURSOR;
BEGIN
   OPEN l_cursor FOR
        SELECT ename
          FROM emp
         WHERE deptno =
               department_id_in
      ORDER BY ename;

   DBMS_SQL.return_result (l_cursor);
END;
/


BEGIN
   show_emps (20);
END;
/
