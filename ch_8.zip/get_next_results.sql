set tab off
set pages 999
set lines 120
set serveroutput on

create or replace
procedure show_dept (p_deptno in number)
is
   l_rc sys_refcursor;
begin
   open l_rc
   for
   select deptno
         ,dname
         ,loc
     from dept
    where deptno = p_deptno;
   dbms_sql.return_result(l_rc);
end show_dept;
/

declare
  l_sql_cursor     integer;
  l_rows_processed number;
  l_ref_cursor     sys_refcursor;
  l_deptno         number;
  l_dname          varchar2(20);
  l_loc            varchar2(20);
begin
   l_sql_cursor := dbms_sql.open_cursor (treat_as_client_for_results => true);
   dbms_sql.parse(c             => l_sql_cursor
                 ,statement     => 'begin show_dept(:p_deptno); end;'
                 ,language_flag => dbms_sql.native
                 );
   dbms_sql.bind_variable (c     => l_sql_cursor
                          ,name  => 'p_deptno'
                          ,value => 10
                          );
   l_rows_processed := dbms_sql.execute (c => l_sql_cursor);
   dbms_sql.get_next_result (c  => l_sql_cursor
                            ,rc => l_ref_cursor
                            );
   fetch l_ref_cursor into l_deptno
                          ,l_dname
                          ,l_loc;
   dbms_output.put_line ('Department Number: '|| to_char (l_deptno));
   dbms_output.put_line ('Department Name  : '|| l_dname);
   dbms_output.put_line ('Location         : '|| l_loc);
   dbms_sql.close_cursor (c => l_sql_cursor);
   close l_ref_cursor;
end;
/


declare
  l_sql_cursor     integer;
  l_sql_cursor2     integer;
  l_rows_processed number;
  l_ref_cursor     sys_refcursor;
  l_deptno         number;
  l_dname          varchar2(20);
  l_loc            varchar2(20);
  l_col_cnt number;
  l_desc_tab DBMS_SQL.desc_tab;
  col_num number;
  PROCEDURE print_rec(rec in DBMS_SQL.DESC_REC) IS
BEGIN
  DBMS_OUTPUT.PUT_LINE('---------');
  DBMS_OUTPUT.PUT_LINE('col_type            =    '
                       || rec.col_type);
  DBMS_OUTPUT.PUT_LINE('col_maxlen          =    '
                       || rec.col_max_len);
  DBMS_OUTPUT.PUT_LINE('col_name            =    '
                       || rec.col_name);
  DBMS_OUTPUT.PUT_LINE('col_name_len        =    '
                       || rec.col_name_len);
  DBMS_OUTPUT.PUT_LINE('col_schema_name     =    '
                       || rec.col_schema_name);
  DBMS_OUTPUT.PUT_LINE('col_schema_name_len =    '
                       || rec.col_schema_name_len);
  DBMS_OUTPUT.PUT_LINE('col_precision       =    '
                       || rec.col_precision);
  DBMS_OUTPUT.PUT_LINE('col_scale           =    '
                       || rec.col_scale);
  DBMS_OUTPUT.PUT('col_null_ok         =    ');
  IF (rec.col_null_ok) THEN
    DBMS_OUTPUT.PUT_LINE('true');
  ELSE
    DBMS_OUTPUT.PUT_LINE('false');
  END IF;
END print_rec;
begin
   l_sql_cursor := dbms_sql.open_cursor (treat_as_client_for_results => true);
   dbms_sql.parse(c             => l_sql_cursor
                 ,statement     => 'begin show_dept(:p_deptno); end;'
                 ,language_flag => dbms_sql.native
                 );
   dbms_sql.bind_variable (c     => l_sql_cursor
                          ,name  => 'p_deptno'
                          ,value => 10
                          );
   l_rows_processed := dbms_sql.execute (c => l_sql_cursor);
   loop
      begin
         dbms_sql.get_next_result (c  => l_sql_cursor
                                  ,rc => l_ref_cursor
                                  );
      exception
         when no_data_found
         then
            exit;
      end;
      l_sql_cursor2 := DBMS_SQL.to_cursor_number(l_ref_cursor);
      DBMS_SQL.describe_columns (l_sql_cursor2, l_col_cnt, l_desc_tab);
      dbms_output.put_line('cnt: '||l_col_cnt);
      -- dbms_output.put_line('cnt: '||l_col_cnt);
      -- l_ref_cursor := DBMS_SQL.to_refcursor(l_sql_cursor);
      col_num := l_desc_tab.first;
      IF (col_num IS NOT NULL) THEN
        LOOP
          print_rec(l_desc_tab(col_num));
          col_num := l_desc_tab.next(col_num);
          EXIT WHEN (col_num IS NULL);
        END LOOP;
      END IF;

   end loop;
   dbms_sql.close_cursor (c => l_sql_cursor);
end;
/


--
--
--     l_return := DBMS_SQL.execute(l_sql_cursor);
--
--     -- Loop through retrieving every resultset.
--     LOOP
--       -- Get the next resultset.
--       BEGIN
--         DBMS_SQL.get_next_result(l_sql_cursor, l_ref_cursor);
--       EXCEPTION
--         WHEN NO_DATA_FOUND THEN
--           EXIT;
--       END;
--
--       -- Describe the resultset, to check the number of columns.
--       l_return := DBMS_SQL.to_cursor_number(l_ref_cursor);
--       DBMS_SQL.describe_columns (l_return, l_col_cnt, l_desc_tab);
--       l_ref_cursor := DBMS_SQL.to_refcursor(l_return);
--
--       -- Process the result set according to the number of columns.
--       CASE l_col_cnt
--         WHEN 1 THEN
--           DBMS_OUTPUT.put_line('It must be the COUNT');
--           FETCH l_ref_cursor
--           INTO  l_count;
--
--           DBMS_OUTPUT.put_line('l_count=' || l_count);
--           CLOSE l_ref_cursor;
--         WHEN 2 THEN
--           DBMS_OUTPUT.put_line('It must be the DESCRIPTION and CREATED_DATE.');
--           LOOP
--             FETCH l_ref_cursor
--             INTO  l_description, l_created_date;
--
--             EXIT WHEN l_ref_cursor%NOTFOUND;
--
--             DBMS_OUTPUT.put_line('l_description=' || l_description || '  ' ||
--                                  'l_created_date=' || TO_CHAR(l_created_date, 'DD-MON-YYYY'));
--           END LOOP;
--           CLOSE l_ref_cursor;
--         ELSE
--           DBMS_OUTPUT.put_Line('I wasn''t expecting that!');
--       END CASE;
--     END LOOP;
--   END;
--
--    l_stmt := 'begin show_dept(:p_deptno); end;';
--    execute immediate l_stmt
--      using p_deptno
--           ,p_show_emps
--    ;
--    dbms_sql.to_refcuror ();
--    DBMS_SQL.get_next_result ()
-- l_result   VARCHAR2(10);
-- BEGIN
-- l_sql := 'SELECT boolean_test(:l_boolean) INTO :l_result FROM dual';
-- EXECUTE IMMEDIATE l_sql INTO l_result USING l_boolean;
-- DBMS_OUTPUT.put_line('l_result=' || l_result);
-- END;
--   c := DBMS_SQL.OPEN_CURSOR(true);
--   DBMS_SQL.PARSE(c, 'BEGIN show_dept_emps(:p_deptno, :p_show_emps); END;', DBMS_SQL.NATIVE);
--   DBMS_SQL.BIND_VARIABLE(c, ':id', 176);
--   DBMS_SQL.BIND_VARIABLE(c, ':p_show_emps', 'false');
--   n := DBMS_SQL.EXECUTE(c);
--
--   -- Get employee info
--
--   dbms_sql.get_next_result(c, rc);
--   FETCH rc INTO first_name, last_name, email, phone_number;
--
--   DBMS_OUTPUT.PUT_LINE('Employee: '||first_name || ' ' || last_name);
--   DBMS_OUTPUT.PUT_LINE('Email: ' ||email);
--   DBMS_OUTPUT.PUT_LINE('Phone: ' ||phone_number);
--
--   -- Get employee job history
--
--   DBMS_OUTPUT.PUT_LINE('Titles:');
--   DBMS_SQL.GET_NEXT_RESULT(c, rc);
--   LOOP
--     FETCH rc INTO job_title, start_date, end_date;
--     EXIT WHEN rc%NOTFOUND;
--     DBMS_OUTPUT.PUT_LINE
--       ('- '||job_title||' ('||start_date||' - ' ||end_date||')');
--   END LOOP;
--
--   DBMS_SQL.CLOSE_CURSOR(c);
-- END main;
-- /
