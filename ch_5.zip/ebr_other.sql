set echo on
set serveroutput on

col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr

conn sys/oracle@pdborcl as sysdba


drop user noned cascade
/

create user noned identified by noned
default tablespace users quota unlimited on users
/
grant create session, create procedure, create table to noned
/

pause
conn alex/alex@pdborcl
set serveroutput on

select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause

create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello World');
end hello;
/

grant execute on hello to noned
/

pause
conn noned/noned@pdborcl
set serveroutput on
begin
   alex.hello;
end;
/

conn alex/alex@pdborcl
set serveroutput on
pause
cl scr

create edition R1 as child of ora$base
/

pause

alter session set edition = R1
/
pause
cl scr


create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello Universe');
end hello;
/
pause
grant use on edition r1 to noned
/

pause
conn noned/noned@pdborcl
set serveroutput on
select object_name
     , object_type
     , edition_name
  from all_objects_ae
 where object_name = 'HELLO'
   and owner = 'ALEX'
/

begin
   alex.hello;
end;
/
alter session set edition = r1
/
begin
   alex.hello;
end;
/

create or replace
procedure test
is
begin null; end test;
/


select object_name
     , object_type
     , edition_name
  from user_objects_ae
 where object_name = 'TEST'
/


pause
conn alex/alex@pdborcl edition = r1
set serveroutput on
begin
   hello;
end;
/

alter session set edition = ora$base
/


begin
   hello;
end;
/

pause ++ Cleanup ++
alter session set edition = ora$base
/

drop edition r1 cascade
/

drop procedure hello
/
