@@setup.sql

alter database default edition = r1
/

conn alex/alex@pdborcl

show edition
pause Change Default edition

alter database default edition = ora$base
/

pause
select property_value from database_properties
  where property_name = 'DEFAULT_EDITION';

pause

conn alex/alex@pdborcl

show edition


pause

conn sys/oracle@pdborcl as sysdba
alter session set edition = ora$base
/
alter database default edition = ora$base
/


pause cleanup
@@cleanup.sql
