set tab off
set pages 999
set lines 120

@@cleanup

set echo on
col trigger_name format a30
col table_name format a30

create table emp
as
select *
  from scott.emp
/

create sequence empseq
/
create or replace trigger emp_bir
before insert on emp
for each row
begin
   :new.empno := empseq.nextval;
end emp_bir;
/

alter table emp rename to "_emp"
/
select trigger_name
      ,table_name
  from user_triggers
/

drop trigger emp_bir
/

create editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
  from "_emp"
/

create or replace trigger emp_bir
before insert on emp
for each row
begin
   :new.empno := empseq.nextval;
end emp_bir;
/
select trigger_name
      ,table_name
  from user_triggers
/

drop sequence empseq
/
