/*
|| Setup and Forward Crossedition Trigger
*/
col "Current_Edition" format a20
col object_name format a20
@@cleanup
@@setup
set echo on
cl scr


alter session set edition = R1
/

pause
select ename
  from emp
/

pause
alter session set edition = R2
/

pause
select empno
     , first_name
     , last_name
  from emp
/

pause
cl scr

set echo off
prompt
prompt [== Forward Cross Edition Trigger        ==]
prompt [== DML on earlier editions fire trigger ==]
prompt
set echo on
select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/
pause

create or replace trigger EMP_R1_R2_Fwd_Xed
before insert or update on "_emp"
for each row
forward crossedition
-- trigger is created enabled
enable
begin
   -- Will create an invalid trigger
   -- there is a missing semi-colon
   :new.last_name := :new.ename
end EMP_R1_R2_Fwd_Xed;
/

pause


cl scr
set echo off
prompt
prompt [== Test Trigger from Base Edition ==]
prompt
set echo on


alter session set edition = R1
/

pause

update emp
   set ename = ename
 where empno = 7788
/
commit
/

pause

alter session set edition = R2
/

select empno
     , first_name
     , last_name
  from emp
/


pause ++ Done ++
