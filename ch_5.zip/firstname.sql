set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr
alter session set edition = ora$base
/
drop edition r2 cascade
/
drop edition r1 cascade
/

drop view emp
/

drop table "_emp" purge
/
create table emp
as
select *
  from scott.emp
/


select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause


alter table emp rename to "_emp"
/

pause

create editioning view emp
as
select *
  from "_emp"
/


pause
alter table "_emp"
add (
    phone_number varchar2 (10)
)
/
create edition r1 as child of ora$base
/

alter session set edition = r1
/
create or replace editioning view emp
as
select *
  from "_emp"
/

alter session set edition = ora$base
/

alter table "_emp"
add (
    first_name varchar2 (10)
   ,last_name varchar2 (10)
)
/


create edition r2 as child of r1
/
pause

alter session set edition = r2
/
create or replace
   editioning view emp
as
select empno
      ,first_name
      ,last_name
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
      ,phone_number
  from "_emp"
/

pause

select *
  from emp
/

----- Hier doorgaan met het synchronisersn van data
-- cross edition triggers enzo
