set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr
drop view emp
/

alter table "_emp" rename to emp
/

drop table emp purge
/
create table emp
as
select *
  from scott.emp
/


select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause


alter table emp rename to "_emp"
/

pause

create editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
  from "_emp"
/


pause
select *
  from emp
/

alter table "_emp"
add (
   phone_number varchar2(10)
)
/


create edition r1 as child of ora$base
/
pause

alter session set edition = r1
/
create or replace
   editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
      ,phone_number
  from "_emp"
/

pause

select empno
      ,ename
      ,phone_number
  from emp
/

alter session set edition = ora$base
/
desc emp

pause

alter session set edition = ora$base
/
drop edition r1 cascade
/
