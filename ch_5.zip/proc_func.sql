set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr


select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause

create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello World');
end hello;
/

pause

cl scr

create edition R1 as child of ora$base
/

pause

alter session set edition = R1
/
pause
cl scr
set serveroutput on
drop procedure hello
/
create or replace
function hello return varchar2
is
begin
   return 'Hello World';
end hello;
/
begin
   hello;
end;
/
begin
   dbms_output.put_line(hello);
end;
/
pause
select object_name
     , object_type
     , edition_name
  from all_objects_ae
 where object_name = 'HELLO'
   and owner = 'ALEX'
/

pause
cl scr

pause ++ Cleanup ++
alter session set edition = ora$base
/
drop edition r2 cascade
/
drop edition r1 cascade
/

drop procedure hello
/
