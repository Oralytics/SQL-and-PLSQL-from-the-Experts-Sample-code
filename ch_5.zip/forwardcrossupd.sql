/*
|| Setup and Forward Crossedition Trigger
*/
col "Current_Edition" format a20
col object_name format a20
@@cleanup
@@setup
set echo on
cl scr


alter session set edition = R1
/

pause
select ename
  from emp
/

pause
alter session set edition = R2
/

pause
select empno
     , first_name
     , last_name
  from emp
/

pause
cl scr

set echo off
prompt
prompt [== Forward Cross Edition Trigger        ==]
prompt [== DML on earlier editions fire trigger ==]
prompt
set echo on
select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/
pause

create or replace trigger EMP_R1_R2_Fwd_Xed
before insert or update on "_emp"
for each row
forward crossedition
disable
begin
   :new.last_name := :new.ename;
end EMP_R1_R2_Fwd_Xed;
/

pause
set echo off
prompt
prompt [== Enable Trigger ==]
prompt
set echo on

alter trigger EMP_R1_R2_Fwd_Xed enable
/


pause
cl scr
set echo off
prompt
prompt [== Test Trigger from Base Edition ==]
prompt
set echo on


alter session set edition = R1
/

pause

update emp
   set ename = ename
 where empno = 7788
/
commit
/


alter session set edition = ora$base
/

pause

update emp
   set ename = 'Nuijten'
 where empno = 7782
/
commit
/

pause
cl scr

alter session set edition = r1
/
pause

select empno
     , ename
  from emp
 where empno in (7782, 7788)
/
pause
cl scr

alter session set edition = R2
/

select empno
     , first_name
     , last_name
  from emp
 where empno in (7782, 7788)
/

pause


cl scr
set echo off
prompt
prompt [== Use Forward Crossedition Trigger     ==]
prompt [== to upgrade existing records in table ==]
prompt [== Consider: DBMS_PARALLEL_EXECUTE      ==]
prompt
set echo on

select empno
     , first_name
     , last_name
  from emp
/
pause
cl scr

update "_emp"
  set empno = empno
/
commit;

pause

select empno
      ,first_name
      ,last_name
  from emp
/
-- declare
--   c number := dbms_sql.open_cursor();
--   x number;
-- begin
--    dbms_sql.parse
--    ( c => c
--    , Language_Flag => dbms_sql.native
--    , Statement => 'UPDATE "_emp"
--                    SET EMPNO = EMPNO'
--    , Apply_Crossedition_Trigger => 'EMP_R1_R2_Fwd_Xed'
--    );
--    x := dbms_sql.execute(c);
--    dbms_sql.close_cursor(c);
--    commit;
-- end;
-- /

pause ++ Done ++


cl scr
