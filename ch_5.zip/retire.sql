set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

@@cleanup

conn alex/alex@pdborcl

select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

create or replace
procedure hello
is
begin
   dbms_output.put_line('Hello from ORA$BASE');
end;
/
pause
set serveroutput on
begin
   hello;
end;
/
conn sys/oracle@pdborcl as sysdba

create edition R1 as child of ora$base
/
grant use on edition r1 to alex
/

create edition R2 as child of R1
/
grant use on edition r2 to alex
/
pause
conn alex/alex@pdborcl edition = R2
set serveroutput on
begin
   hello;
end;
/

pause

conn sys/oracle@pdborcl as sysdba
revoke use on edition r1 from alex
/

conn alex/alex@pdborcl edition = ora$base
set serveroutput on
begin
   hello;
end;
/

pause

conn alex/alex@pdborcl edition = r1

pause
conn alex/alex@pdborcl edition = r2
set serveroutput on
begin
   hello;
end;
/


pause
select object_name
     , object_type
     , edition_name
  from user_objects_ae
 where object_name = 'HELLO'
/

pause

conn sys/oracle@pdborcl as sysdba
pause ++ Cleanup ++
alter session set edition = ora$base
/
drop edition r2 cascade
/

drop edition r1 cascade
/
