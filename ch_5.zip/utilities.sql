@@setup.sql

pause Edition Object ID
col object_name format a30
col edition_name format a30
column object_id new_value object_id

select object_name
      ,object_id
  from all_objects
 where object_name in( 'ORA$BASE' , 'R1' )
;


pause Compare Editions
set echo on
-- IDENTICAL  constant integer := 0;
-- ANCESTOR   constant integer := 1;
-- DESCENDENT constant integer := 2;
-- unrelated  constant integer := 3;

select dbms_editions_utilities.compare_edition(133, &object_id)
  from dual;

pause Setting editioning views read only
col view_name format a30
select view_name
      ,read_only
      ,edition_name
  from all_views_ae
 where owner = user
/
pause
begin
   dbms_editions_utilities.set_editioning_views_read_only (
      table_name => '_emp',
      owner      => user,
      read_only  => TRUE);
end;
/

pause
select view_name
      ,read_only
      ,edition_name
  from all_views_ae
 where owner = user
/

pause Null Column value as expression
prompt Enable DML on the editioning views
begin
   dbms_editions_utilities.set_editioning_views_read_only (
      table_name => '_emp',
      owner      => user,
      read_only  => false);
end;
/
pause

-- update "_emp"
--    set last_name = 'NUIJTEN'
--  where rownum = 1
-- /
-- commit
-- /

pause
declare
   expr constant varchar2(30) := 'LOWER (ENAME)';
begin
   dbms_editions_utilities.set_null_column_values_to_expr
      (table_name  => '"_emp"'
      ,column_name => 'last_name'
      ,expression  => expr);
end;
/
select ename
      ,last_name
  from "_emp"
/
-- pause switch edition
--
-- alter session set edition = r2
-- /
-- pause show results
--
-- select last_name
--   from emp
-- /
-- pause
--
-- alter session set edition = r1
-- /
--
-- select ename
-- insert into emp (empno, ename)
-- values (42, 'MARVIN')
-- /
--
-- select *
--   from emp
-- /
-- commit
-- /
--
-- alter session set edition = r2
-- /
-- select *
--   from emp
-- /
--
pause Cleanup
@@cleanup
