set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr
drop view emp
/

alter table "_emp" rename to emp
/

select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause


alter table emp rename to "_emp"
/

pause

create editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
  from "_emp"
/


pause
select *
  from emp
/
