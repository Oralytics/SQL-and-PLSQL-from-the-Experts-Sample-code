cl scr
conn alex/alex@pdborcl

alter session set edition = ora$base
/

create edition r1 as child of ora$Base
/
create edition r2 as child of r1
/

create table emp
as
select *
  from scott.emp
/

alter table emp rename to "_emp"
/
alter table "_emp"
add (
   phone_number varchar2(10)
  ,first_name varchar2(10)
  ,last_name varchar2(25)
)
/

create editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
  from "_emp"
/


alter session set edition = r1
/
create or replace editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
      ,phone_number
  from "_emp"
/

alter session set edition = r2
/
create or replace editioning view emp
as
select empno
      ,first_name
      ,last_name
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
      ,phone_number
  from "_emp"
/
alter session set edition = ora$base
/
sho user
sho Edition
