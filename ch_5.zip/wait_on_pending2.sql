conn alex/alex@pdborcl edition=ora$base

set serveroutput on
set echo on

declare
  l_bool boolean;
  l_scn number;
begin
  l_scn := timestamp_to_scn (systimestamp);
  l_bool := dbms_utility.wait_on_pending_dml
              ( tables => 'alex.s',
                timeout => null,
                scn => l_scn );
  dbms_output.put_line( 'scn:  ' || l_scn );
  dbms_output.put_line( 'now we start to do our thing' );
  l_scn := timestamp_to_scn (systimestamp);
  dbms_output.put_line( 'scn:  ' || l_scn );
end;
/
