@@cleanup.sql
@@setup.sql
@@forwardcrosstrg.sql

col "Current_Edition" format a20
col object_name format a20

set echo on
cl scr

set echo off
prompt
prompt [==           Edition R2            ==]
prompt [== DML effect on earlier Editions  ==]
prompt
set echo on

alter session set edition = r2
/

pause
cl scr
set echo off
prompt
prompt [== Reverse Crossedition Trigger ==]
prompt [== Set ename based on LastName  ==]
prompt
set echo on

create or replace trigger EMP_R2_R1_Rve_Xed
before insert or update of last_name on "_emp"
for each row
reverse crossedition
disable
begin
  :new.ename := substr(:new.last_name, 1, 10);
end EMP_R2_R1_Rve_Xed;
/


pause


alter trigger EMP_R2_R1_Rve_Xed enable
/

pause
cl scr
pause

insert into emp
   (empno, first_name, last_name)
values
   (8181, 'Heli', 'FromFinland')
/
update emp
   set first_name ='Arup'
      ,last_name = 'Nanda'
 where empno = 7839
/
merge into emp e
using (select 8888      empno
             ,'Brendan' first_name
             ,'Tierney' last_name
         from dual
      ) new_emp
on (e.empno = new_emp.empno)
when not matched
then
   insert
      (empno
      ,first_name
      ,last_name)
   values
      (new_emp.empno
      ,new_emp.first_name
      ,new_emp.last_name)
/

commit
/

pause
cl scr

alter session set edition = R1
/
pause

update emp
   set ename = 'Widlake'
 where ename = 'MARTIN'
/

commit
/


pause
select empno
      ,ename
  from emp
 where empno in (7654, 7839, 8181, 8888)
/
alter session set edition = r2
/

pause
select empno
      ,first_name
      ,last_name
  from emp
 where empno in (7654, 7839, 8181, 8888)
/

pause ++ Done ++
