set serveroutput on size 99999
set echo on
clear screen
create table "_emp_"
(empno      number(10) primary key
,ename		varchar2(10)
,first_name varchar2(10)
,last_name  varchar2(10)
);

pause

insert /*+ append */ into "_emp_"
select rownum
      ,ename
      ,null
      ,ename
  from scott.emp
  cross
  join all_objects
where rownum <= 50000
/

pause
create table monitor
(last_empno               number(10)
,number_of_processed_recs number(10)
);

pause
insert into monitor
   values (null, 0)
/
pause
create procedure keep_track (p_empno in number)
is
   pragma autonomous_transaction;
begin
   update monitor
      set last_empno = p_empno
        , number_of_processed_recs = number_of_processed_recs + 1
   ;
   commit;
end keep_track;
/


pause

create trigger emp_aru
 after update on "_emp_"
for each row
begin
   keep_track (:new.empno);
end;
/

pause Setup Editions
create edition r1 as child of ora$Base
/
create edition r2 as child of r1
/

pause create editioning views
alter session set edition = r1
/
create or replace editioning view emp
as
select empno
      ,ename
 from "_emp_"
/

alter session set edition = r2
/
create or replace editioning view emp
as
select empno
      ,first_name
      ,last_name
  from "_emp_"
/

-- pause Forward Cross Edition trigger
-- create or replace trigger EMP_R1_R2_Fwd_Xed
-- before insert or update on "_emp_"
-- for each row
-- forward crossedition
-- disable
-- begin
--    :new.last_name := :new.ename;
-- end EMP_R1_R2_Fwd_Xed;
-- /
--
-- alter trigger EMP_R1_R2_Fwd_Xed enable
-- /

pause Reverse Cross Edition Trigger
create or replace trigger EMP_R2_R1_Rve_Xed
before insert or update of last_name on "_emp_"
for each row
reverse crossedition
disable
begin
  :new.ename := substr(:new.last_name, 1, 10);
end EMP_R2_R1_Rve_Xed;
/



alter trigger EMP_R2_R1_Rve_Xed enable
/
pause

--
--
-- -- Start second session and issue these statement while
-- -- this session is running
-- alter session set edition = r1
-- /
-- select *
--   from monitor
-- /
-- update emp
--    set ename = '-> RESTART'
--  where empno = 42424
-- /
-- commit
-- /
--
-- select *
--   from emp
--  where empno between 42420 and 42430
-- /
--
-- alter session set edition = ora$base
-- /
-- select *
--   from "_emp_"
--  where empno between 42420 and 42430
-- /
--
--
--

pause

update emp
   set last_name = lower (last_name)
/
commit
/


select *
  from emp
 where empno between 42420 and 42430
/

select *
  from monitor
/
pause



pause cleanup
commit
/
alter session set edition = ora$base
/
drop edition r2 cascade
/
drop edition r1 cascade
/

drop procedure keep_track
/
drop table "_emp_"
/
drop table monitor
/
purge recyclebin
/
