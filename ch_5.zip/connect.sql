@@cleanup.sql
@@setup.sql
conn alex/alex@pdborcl edition=r2
