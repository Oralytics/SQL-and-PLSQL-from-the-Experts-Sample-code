set echo on
conn sys/oracle@pdborcl as sysdba

drop user ebr_test cascade
/
drop edition r1 cascade
/

create user ebr_test identified by ebr_test
default tablespace users quota unlimited on users
/
grant create session, create procedure, create table to ebr_test
/
grant execute on dbms_redact to ebr_test
/

alter user ebr_test enable editions
/

conn ebr_test/ebr_test@pdborcl

create table cc_info
(
id number primary key
,cc varchar2(40)
)
/
insert into cc_info
select rownum
      ,dbms_random.value(10000, 20000)
  from dual
 connect by level <= 10
/

select *
  from cc_info
;
begin
   dbms_redact.add_policy
     (object_schema  => 'EBR_TEST'
     ,object_name    => 'CC_INFO'
     ,policy_name    => 'Hide Creditcard'
     ,expression     => '1=1'
     ,column_name    => 'CC'
     ,function_type  => dbms_redact.regexp
     ,regexp_pattern => dbms_redact.re_pattern_any_digit
     ,regexp_replace_string => 'X'
     );
end;
/
col cc format a40
select *
  from cc_info
/

alter table cc_info rename to "_cc_info"
/

select *
  from "_cc_info"
/

conn sys/oracle@pdborcl as sysdba
create edition r1 as child of ora$base
/
grant use on edition r1 to ebr_test
/
grant create view to ebr_test
/


conn ebr_test/ebr_test@pdborcl edition=r1

show edition

create editioning view cc_info
as
select *
  from "_cc_info"
/
select *
  from cc_info
/

prompt *** The following will raise ORA-28061
prompt *** This object cannot have a data redaction policy defined on it.
prompt ***
begin
   dbms_redact.add_policy
     (object_schema  => 'EBR_TEST'
     ,object_name    => 'CC_INFO'
     ,policy_name    => 'Hide Creditcard'
     ,expression     => '1=1'
     ,column_name    => 'CC'
     ,function_type  => dbms_redact.regexp
     ,regexp_pattern => dbms_redact.re_pattern_any_digit
     ,regexp_replace_string => '.'
     );
end;
/
begin
   dbms_redact.drop_policy (
   object_schema                => 'EBR_TEST',
   object_name                  => '"_cc_info"',
   policy_name                  => 'Hide Creditcard');
end;
/
begin
   dbms_redact.add_policy
     (object_schema  => 'EBR_TEST'
     ,object_name    => '"_cc_info"'
     ,policy_name    => 'Hide Creditcard'
     ,expression     => '1=1'
     ,column_name    => 'CC'
     ,function_type  => dbms_redact.regexp
     ,regexp_pattern => dbms_redact.re_pattern_any_digit
     ,regexp_replace_string => '.'
     );
end;
/



select *
  from cc_info
;
