conn scott/tiger@pdborcl

create edition r1 as child of ora$base
/

select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

alter session set edition = r1
/

select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

alter session set edition = ora$base
/

drop edition r1
/
