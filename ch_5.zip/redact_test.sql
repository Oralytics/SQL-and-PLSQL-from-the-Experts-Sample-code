set echo on
conn sys/oracle@pdborcl as sysdba

drop user redact_test cascade
/

create user redact_test identified by redact_test
default tablespace users quota unlimited on users
/
grant create session, create procedure, create table to redact_test
/
grant execute on dbms_redact to redact_test
/

conn redact_test/redact_test@pdborcl

create table "_cc_info"
(id number primary key
,cc varchar2(40))
/
insert into "_cc_info"
select rownum
      ,dbms_random.value(10000, 20000)
  from dual
 connect by level <= 10
/

select *
  from "_cc_info"
;
begin
   dbms_redact.add_policy
     (object_schema  => user
     ,object_name    => '"_cc_info"'
     ,policy_name    => 'Hide Creditcard'
     ,expression     => '1=1'
     ,column_name    => 'CC'
     ,function_type  => dbms_redact.regexp
     ,regexp_pattern => dbms_redact.re_pattern_any_digit
     ,regexp_replace_string => 'X'
     );
end;
/
col cc format a40
select *
  from "_cc_info"
/
create editioning view cc_info
as
select id
      ,cc
  from "_cc_info"
/

select *
  from cc_info
/

update cc_info
   set cc = 1234
 where id= 3
/


select *
  from cc_info
 where id = 3
/


begin
   dbms_redact.drop_policy (
   object_schema                => 'REDACT_TEST',
   object_name                  => 'CC_INFO',
   policy_name                  => 'Hide Creditcard');
end;
/
begin
   dbms_redact.add_policy
     (object_schema  => 'REDACT_TEST'
     ,object_name    => 'CC_INFO'
     ,policy_name    => 'Hide Creditcard'
     ,expression     => '1=1'
     ,column_name    => 'CC'
     ,function_type  => dbms_redact.regexp
     ,regexp_pattern => dbms_redact.re_pattern_any_digit
     ,regexp_replace_string => '.'
     );
end;
/


select *
  from cc_info
;
