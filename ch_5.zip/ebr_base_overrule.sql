set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr


select sys_context('userenv'
                  ,'current_edition_name'
                  ) "Current_Edition"
  from dual
/

pause

create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello World');
end hello;
/

pause
cl scr

begin
   hello;
end;
/

pause

select object_name
     , object_type
     , edition_name
  from user_objects_ae
 where object_name = 'HELLO'
/


pause
cl scr

create edition R1 as child of ora$base
/

pause

alter session set edition = R1
/
pause
cl scr

begin
   hello;
end;
/
pause
cl scr

create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello Universe');
end hello;
/

pause

begin
   hello;
end;
/
pause
cl scr

select object_name
     , object_type
     , edition_name
  from user_objects_ae
 where object_name = 'HELLO'
/


pause
cl scr

alter session set edition = ora$base
/
pause
create or replace
procedure hello
is
begin
   dbms_output.put_line ('Hello Pluto');
end hello;
/

begin
   hello;
end;
/

pause

alter session set edition = R1
/
pause

begin
   hello;
end;
/
pause

pause ++ Cleanup ++
alter session set edition = ora$base
/

drop edition r1 cascade
/

drop procedure hello
/
