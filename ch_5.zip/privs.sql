set echo on
col "Current_Edition" format a20
col object_name format a20
col edition_name format a30

cl scr
conn alex/alex@pdborcl
drop table "_test" purge
/
drop view test
/

create table test
as
select *
  from scott.emp
/

grant select on test to scott
/

pause

conn scott/tiger@pdborcl
set lines 120

select *
  from alex.test
/

pause

conn alex/alex@pdborcl


alter table test rename to "_test"
/

pause

conn scott/tiger@pdborcl
select *
  from alex.test
/

pause
conn alex/alex@pdborcl

create editioning view test
as
select empno
      ,ename
      ,job
  from "_test"
/


pause
conn scott/tiger@pdborcl

select *
  from alex.test
/

pause
conn alex/alex@pdborcl
grant select on test to scott
/

pause
conn scott/tiger@pdborcl

select *
  from alex.test
/
