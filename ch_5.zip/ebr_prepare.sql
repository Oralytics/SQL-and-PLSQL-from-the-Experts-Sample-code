set echo on

conn sys/oracle@pdborcl as sysdba

alter user scott enable editions
/

grant create any edition to scott
/
