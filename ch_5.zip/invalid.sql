@@cleanup
drop procedure show_emp
/

cl scr
conn alex/alex@pdborcl
col object_name format a30

alter session set edition = ora$base
/

create table emp
as
select *
  from scott.emp
/

alter table emp rename to "_emp"
/

create editioning view emp
as
select empno
      ,ename
      ,job
      ,mgr
      ,hiredate
      ,sal
      ,comm
      ,deptno
  from "_emp"
/

create procedure show_emp (p_empno in emp.empno%type)
is
   l_ename emp.ename%type;
begin
   dbms_output.put_line ('Incoming argument: '||p_empno);
   select e.ename
     into l_ename
     from emp e
    where e.empno = p_empno;
   dbms_output.put_line ('This: '||l_ename);
end;
/
sho err

select object_type
      ,object_name
      ,status
  from user_objects
/
alter table "_emp"
add (
   phone_number varchar2(10)
)
/

select object_type
      ,object_name
      ,status
  from user_objects
/

alter table "_emp"
modify (ename varchar2(30))
/
select object_type
      ,object_name
      ,status
  from user_objects
/
