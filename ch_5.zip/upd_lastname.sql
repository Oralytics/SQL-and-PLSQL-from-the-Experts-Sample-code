set echo on

clear screen

create table t
(id  number(9) primary key
,col number(9) not null
);

pause

insert /*+ append */ into t
select level
     , level
  from dual
connect by level <= 50000
/

pause


create table logtable
(last_id                 number(9)
,number_of_processed_ids number(9)
);


insert into logtable values (null,0);

pause
clear screen

create procedure p (p_id in t.id%type)
is
   pragma autonomous_transaction;
begin
   update logtable
      set last_id = p_id
        , number_of_processed_ids = number_of_processed_ids + 1
   ;
   commit;
end p;
/


pause

create trigger t_aru
 after update on t
for each row
begin
   p (:new.id);
end;
/

pause
clear screen

-- Start second session and issue these statement while
-- this session is running
--      select *
--        from logtable
--      /
--      update t
--         set col = 888888
--       where id = 40000
--      /
--      commit
--      /

pause

update /*+ retry_on_row_change */ t
   set col = col * -1
/



pause

select *
  from t
 where id between 39999 and 40001
/
-- Session 2 has set COL to 888888, and session 1 has set this value to -888888.

pause

select *
  from logtable
/


pause cleanup
drop procedure p
/
drop table t
/
drop table logtable
/
purge recyclebin
/
