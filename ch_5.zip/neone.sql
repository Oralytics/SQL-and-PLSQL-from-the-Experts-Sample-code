set echo on
set tab off
set lines 120
set pages 9999

conn sys/oracle@pdborcl as sysdba

create user neone identified by neone
/
grant connect, create table, create type to neone
/
alter user neone quota unlimited on users
/
conn neone/neone@pdborcl

create type phone_number_ot as object
(type_name varchar2(10)
,phone_number varchar2(20)
)
/

create type phone_numbers_tt as table of phone_number_ot
/


create table emps
(empno number
,phone_numbers phone_numbers_tt
)
 nested table phone_numbers store as phone_numbers_nt
/
insert into emps
values (1, phone_numbers_tt(phone_number_ot('Mobile','12345')
,phone_number_ot('Work', '5678')))
/



select e.empno
      ,t.type_name
      ,t.phone_number
  from emps e
      ,table (e.phone_numbers) t
/

commit
/
conn sys/oracle@pdborcl as sysdba

prompt ----------- This fails, of course
alter user neone enable editions
/

conn neone/neone@pdborcl

prompt ------------ Changing the types that the table depend upon to noneditionable does the trick
alter type phone_numbers_tt noneditionable
/
alter type phone_number_ot noneditionable
/

conn sys/oracle@pdborcl as sysdba

alter user neone enable editions
/



prompt ----------- Try to create a table on an editioned type in Scott

conn scott/tiger@pdborcl edition = r3

create type phone_number_ot as object
(type_name varchar2(10)
,phone_number varchar2(20)
)
/

create type phone_numbers_tt as table of phone_number_ot
/

prompt -------------- Here comes the failure

create table emps
(empno number
,phone_numbers phone_numbers_tt
)
 nested table phone_numbers store as phone_numbers_nt
/
prompt -------------- This is not allowed

alter type phone_numbers_tt noneditionable
/
alter type phone_number_ot noneditionable
/

prompt --------------- To be able to have UDT as a column
drop type phone_numbers_tt
/
drop type phone_number_ot
/
prompt ---------------- Here is the solution
create or replace
 noneditionable type phone_number_ot as object
(type_name varchar2(10)
,phone_number varchar2(20)
)
/
create or replace
 noneditionable type phone_numbers_tt as table of phone_number_ot
/

create table emps
(empno number
,phone_numbers phone_numbers_tt
)
 nested table phone_numbers store as phone_numbers_nt
/


prompt -------------- Cleanup
drop table emps purge
/
drop type phone_numbers_tt
/
drop type phone_number_ot
/
conn sys/oracle@pdborcl as sysdba

drop user neone cascade
/
