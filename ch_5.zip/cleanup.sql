cl scr

conn sys/oracle@pdborcl as sysdba

alter session set edition = ora$base
/
drop edition r2 cascade
/
drop edition r1 cascade
/
conn alex/alex@pdborcl

drop view emp
/

drop table "_emp"
/

sho user edition
