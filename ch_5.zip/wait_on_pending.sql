cl scr
conn alex/alex@pdborcl edition = ora$base

drop table s purge
/

create table s
   (x number)
/

begin
  for i in 1..100 loop
    insert into s ( x )
    values ( dbms_random.value );
    dbms_lock.sleep( .1  );
  end loop;
  commit;
end;
/
