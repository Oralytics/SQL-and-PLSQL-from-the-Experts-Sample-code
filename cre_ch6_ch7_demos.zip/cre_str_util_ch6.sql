-- The below is only need THE FIRST TIME you run this script, but you can ignore the error
-- on subsequent executions
create table exec_func_track
(function_name     varchar2(30) not null
,exec_timestamp    timestamp    not null
,extra_info        varchar2(100)
)
/
-- cre_str_util.sql;
-- mdw 09/11/2001
-- package to consolidate implementing string handling functions
-- the name could be more descriptive but it keeps the function names short
--
-- mdw 09/11/2001 Inital build
-- amw 13/08/2004 added function: origin
-- mdw 20/09/2006 adding in something to pull out partition definition
-- mdw 13/02/2011 altered number to pls_integer in PIECE
-- mdw 11/08/2015 modifying to make smaller and more suitable for SQL & PL/SQL book
create or replace package str_util as
type string_func_tabtype is table of varchar2(2000)
     index by binary_integer;
function num_inc(p_text in varchar2
                ,p_incr in pls_integer :=1)
return varchar2;
function num_part(p_text in varchar2)
return number;
function tab_alias (p_tab_name in varchar2
                   ,p_delimiter in varchar2 :='_')
return varchar2;
procedure string_split (p_string    in  varchar2
                       ,p_delimiter in  varchar2            :=','
                       ,p_table     out string_func_tabtype
                       ,p_count     out number);
function piece (p_string    in varchar2
               ,p_start     in pls_integer 
               ,p_end       in pls_integer   := null
               ,p_delimiter in varchar2 := ',')
return varchar2;
function piece (p_string    in varchar2
               ,p_start     in pls_integer 
               ,p_delimiter in varchar2 := ',')
return varchar2;
function disp_name (p_sn      in varchar2
                   ,p_fn1     in varchar2
                   ,p_fn2     in varchar2 :=null
                   ,p_title   in varchar2 :=null)
return varchar2 deterministic;
--
function disp_name_udf (p_sn      in varchar2
                   ,p_fn1     in varchar2
                   ,p_fn2     in varchar2 -- :=null
                   ,p_title   in varchar2)-- :=null)
return varchar2 deterministic;
--
function year_adult (p_dob   in date)
return integer deterministic;
function year_adult_udf (p_dob   in date)
return integer deterministic;
--
procedure func_track (p_vc1 in varchar2);
function dr1
return number;
function dr2
return number;
function get_ts (p_vc1 in varchar2)
return timestamp;
--
end str_util;
/
--
create or replace package body str_util as
-- private package variables
function num_inc(p_text in varchar2
                ,p_incr in pls_integer :=1)
return varchar2 is
v_return varchar2(4000);
v_translate     varchar2(4000);
v_text          varchar2(4000);
v_num_start     pls_integer;
v_num_end       pls_integer;
v_length        pls_integer;
v_num_text      varchar2(4000);
v_number        pls_integer;
v_incr          pls_integer;
begin
  v_text := substr(p_text,1,4000);
  v_incr := p_incr;
  v_translate := translate(v_text,'1234567890'
                                 ,'9999999999');
  if instr(v_translate,'9') = 0 then
    v_return := v_text;
  else
    v_num_start := instr(v_translate,'9');
    v_num_end   := instr(v_translate,'9',-1);
    v_length    := (v_num_end-v_num_start)+1;
    v_num_text  := substr(v_text,v_num_start,v_length);
    if rpad('9',v_length,'9') != substr(v_translate,v_num_start,v_length) then
      -- the extracted number holds non-numerics!
      v_return := v_text;
    else
      v_return := substr(v_text,1,v_num_start-1)
                  ||to_char(v_num_text+v_incr)
                  ||substr(v_text,v_num_end+1);
    end if;
  end if;
  return v_return;
end;
--
function num_part(p_text in varchar2)
return number is
v_return varchar2(4000);
v_translate     varchar2(4000);
v_text          varchar2(4000);
v_num_start     pls_integer;
v_num_end       pls_integer;
v_length        pls_integer;
v_num_text      varchar2(4000);
v_number        pls_integer;
begin
  v_text := substr(p_text,1,4000);
  v_translate := translate(v_text,'1234567890'
                                 ,'9999999999');
  if instr(v_translate,'9') = 0 then
    v_return := null;
  else
    v_num_start := instr(v_translate,'9');
    v_num_end   := instr(v_translate,'9',-1);
    v_length    := (v_num_end-v_num_start)+1;
    v_num_text  := substr(v_text,v_num_start,v_length);
    if rpad('9',v_length,'9') != substr(v_translate,v_num_start,v_length) then
      -- the extracted number holds non-numerics!
      v_return := null;
    else
      v_return := to_number(v_num_text);
    end if;
  end if;
  return v_return;
end;
--
function tab_alias (p_tab_name in varchar2
                   ,p_delimiter in varchar2 :='_')
--  returns the table alias as derived according to standards
-- relies on the tablename being "_" delimited and there
-- being no duplicates like sample_point and saved_portion
return varchar2 is
--v_tab_name all_tables.table_name%type;
v_tab_name varchar2(180);
v_return   varchar2(10);
v_words    number;
v_bitsize  number;
v_rtn_temp varchar2(10);
begin
  v_tab_name := upper(p_tab_name);
  v_words := length(v_tab_name)- length(replace(v_tab_name,p_delimiter))+1;
  v_bitsize :=  greatest(1,6-(2*v_words));
  for a in 1..v_words loop
    v_return := v_return||substr(piece(v_tab_name,a,p_delimiter)
                                ,1,v_bitsize);
  end loop;
  --v_return := to_char(v_words);
  return v_return;
end tab_alias;
--
--
procedure string_split (p_string    in     varchar2
                       ,p_delimiter in     varchar2 := ','
                       ,p_table     out    string_func_tabtype
                       ,p_count     out    number)
-- This is a FAST utility to strip out the parts of a string as delimited by
-- a passed in character. It is not intended to be generic and cope with
-- anything. A separate procedure will have to be written for that.
-- This procedure relies on the delimiter being 1 character and the fields not
-- being quoted and all spaces either side of the fields being superfluous.
is
v_string    varchar2(2000) := p_string;
v_delimiter varchar2(1) := p_delimiter;
v_from      number      :=1;
v_to        number;
v_count     number      :=1;
v_continue  boolean     := true;
begin
  p_count := 0;
  if v_string is null
  or v_delimiter is null then -- missing parameters
    p_table.delete;
  elsif instr(v_string,v_delimiter,1,1) = 0 then
    p_table(1) := v_string;
    p_count := 1;
  else
  -- string and delimiter valid.
  -- There are two tacks I could take. Just scan through the whole string 1
  -- character at a time and create the table entries.
  -- Or use repeated instrings until I run out of text.
    begin
      while v_continue
      loop
        -- below instr counts from last delimiter found as should
        -- save time scanning whole string repeatedly internally
        v_to :=instr(v_string,v_delimiter,v_from,1);
        if v_to = 0 then
           v_to :=length(v_string)+1;
           v_continue := false;
        end if;
        p_table(v_count) := ltrim(rtrim(
                            substr(v_string,v_from,(v_to-v_from))
                                  )     );
        v_from :=v_to+1;
        v_count := v_count+1;
      end loop;
    p_count := v_count-1;
    end;
  end if;
end string_split;
--
function piece (p_string in varchar2
               ,p_start     in pls_integer
               ,p_end       in pls_integer   := null
               ,p_delimiter in varchar2 := ',')
return varchar2
-- Accept string; first piece wanted; optional to end piece; optional delimiter
-- ',' as default.
-- If parameters invalid, return null
-- If first piece exists but string ends before end piece found, return
-- whole of string from first piece.
-- If a range of pieces requested, delimiters within the returned string remain.
is
v_string    varchar2(2000) := p_string;
v_start     pls_integer    := floor(abs(p_start));
v_end       number         := floor(abs(p_end));
v_delimiter varchar2(20)   := p_delimiter;
v_return    varchar2(2000) := null;
v_dlen      pls_integer    :=length(v_delimiter);
v_from      pls_integer;
v_to        pls_integer;
begin
if v_string is null
or v_start is null
or v_delimiter is null then -- missing parameters
  null;
elsif v_start > 1
and   instr(v_string,v_delimiter,1,greatest(v_start-1,1)) =0 then -- no nth part
  null;
elsif v_end <v_start then
  null;
else -- all parameters make sense. Maybe this is all overkill, but
     -- might as well do correctly.
  if v_start <2 then      -- ie want first part
    v_from :=1;           -- ensure v_from is 1
    v_start :=1;          -- Start at begining of string
  else
    v_from := instr(v_string,v_delimiter,1,v_start-1)+v_dlen;
  end if;
  if v_end is null then
    v_end := v_start;
  end if;
  v_to := instr(v_string,v_delimiter,1,v_end) -1;
  if v_to = -1 then
    v_to := length(v_string);
  end if;
  v_return := substr(v_string
                    ,v_from
                    ,(v_to-v_from)+1);
end if;
return v_return;
end piece;
-- overloaded function to allow simple "this piece only" usage
function piece (p_string in varchar2
               ,p_start     in pls_integer 
               ,p_delimiter in varchar2 := ',')
return varchar2
is
v_temp varchar2(2000);
begin
v_temp := piece(p_string,p_start,null,p_delimiter);
return v_temp;
end piece;
--
function disp_name (p_sn      in varchar2
                   ,p_fn1     in varchar2
                   ,p_fn2     in varchar2  :=null
                   ,p_title   in varchar2  :=null)
return varchar2 
deterministic
is
v_return     varchar2(1000);
begin
  -- NVL2 and DECODE not available in PL/SQL (still true in 12)
  v_return := case when p_title is null then ''
                   else initcap(p_title)||' '
              end
            ||initcap(p_fn1)||' '
            ||case when p_fn2 is null then ''
                   else substr(p_fn2,1,1)||' '
              end
            ||initcap(p_sn);
return v_return;
end disp_name;
--
function disp_name_udf (p_sn      in varchar2
                       ,p_fn1     in varchar2
                       ,p_fn2     in varchar2  
                       ,p_title   in varchar2  ) return varchar2 is
PRAGMA UDF;
v_return     varchar2(1000);
begin
  v_return := case when p_title is null then ''
                   else initcap(p_title)||' '
              end
            ||initcap(p_fn1)||' '
            ||case when p_fn2 is null then ''
                   else substr(p_fn2,1,1)||' '
              end
            ||initcap(p_sn);
return v_return;
end;
--
--
function dr1
return number
is
begin
  return dbms_random.value;
end dr1;
function dr2
return number
is
begin
  return dbms_random.value;
end dr2;
--
procedure func_track (p_vc1 in varchar2)
is
pragma autonomous_transaction;
begin
  insert into exec_func_track (function_name,exec_timestamp)
  values (p_vc1,SYSTIMESTAMP);
  commit;
end func_track;
--
function get_ts (p_vc1 in varchar2)
return timestamp
is
b number;
begin
  -- the time-waste loop is needed as systimestamp is from the system clock that ticks too slow
  -- for two calls on same row to come up with a different result if we just pass back systimestamp
  for a in 1..100000 loop
    b:=sqrt(a);
  end loop;  
--  func_track('get_ts');
  return systimestamp;
end get_ts;
--
function year_adult (p_dob   in date)
return integer deterministic
is
begin  
  return to_number(to_char(p_dob,'YYYY'))+18;
end year_adult;
--
function year_adult_udf (p_dob   in date)
return integer deterministic
is
pragma udf;
begin  
  return to_number(to_char(p_dob,'YYYY'))+18;
end year_adult_udf;
--
-- Initialisation section
begin
  null;
end str_util;
/