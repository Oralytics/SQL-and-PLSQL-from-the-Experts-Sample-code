-- cre_ch6_demos
-- create all the demonstration packages and tables for Ch6 of Real World SQL & PL/SQL
--
set timi on
prompt creating the STR_UTIL package
@cre_str_util_ch6.sql
prompt creating the PNA_CRE package
@cre_pna_cre_ch6.sql
prompt and creating the tables
exec pna_cre.cre_tabs
prompt creating the PNA_MAINT package
@cre_pna_maint_ch6.sql
prompt populating source tables, will take under a second
exec pna_maint.pop_source
prompt populating the ADDRESS table with 1 million records, will take a minute or so
exec pna_maint.pop_addr_batch
prompt populating the PERSON and PERSON_NAME tables, will take 1 to 3 minutes
exec pna_maint.pop_pers
prompt creating and populating COUNTRY and ACTIVITY tables, will take 2 to 6 minutes. Sorry
prompt ignore any warnings about failing drop statements
@cre_coun_acti_ch6.sql
prompt finished
