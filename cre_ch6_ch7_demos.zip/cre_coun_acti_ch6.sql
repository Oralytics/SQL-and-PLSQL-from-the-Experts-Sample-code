--cre_coun_acti_ch6.sql
-- create two simple tables used for examples in chapter 6 of
-- Real World SQL & PL/SQL 
drop table country;
drop table activity;
--
create table COUNTRY(ID           number(3)    not null
                    ,NAME         varchar2(40) not null
                    ,EU_IND       varchar2(1)  not null
                    ,SHORT_NAME   varchar2(6) not null
                    ,COUN_COMMENT varchar2(1000)
,constraint coun_pk primary key (id)
 )
/
insert into country
with source as (
select 1 ,'United Kingdom'      ,'Y','UK',null FROM DUAL UNION
select 2 ,'United States of America','N','USA',null FROM DUAL UNION
select 3 ,'India'               ,'N','IND',null FROM DUAL UNION
select 4 ,'Bangladesh'          ,'N','BAN',null FROM DUAL UNION
select 5 ,'Russia'              ,'N','RUS',null FROM DUAL UNION
select 6 ,'Austria'             ,'Y','AUS',null FROM DUAL UNION
select 7 ,'Belgium'             ,'Y','BE',null FROM DUAL UNION
select 8 ,'Bulgaria'            ,'Y','BUL',null FROM DUAL UNION
select 9 ,'Croatia'             ,'Y','CRO',null FROM DUAL UNION
select 10,'Republic of Cyprus'  ,'Y','CYP',null FROM DUAL UNION
select 11,'Czech Republic'      ,'Y','CZ',null FROM DUAL UNION
select 12,'Denmark'             ,'Y','DEN',null FROM DUAL UNION
select 13,'Estonia'             ,'Y','EST',null FROM DUAL UNION
select 14,'Finland'             ,'Y','FIN',null FROM DUAL UNION
select 15,'France'              ,'Y','FR',null FROM DUAL UNION
select 16,'Germany'             ,'Y','GE',null FROM DUAL UNION
select 17,'Greece'              ,'Y','GRE',null FROM DUAL UNION
select 18,'Hungary'             ,'Y','HUN',null FROM DUAL UNION
select 19,'Ireland'             ,'Y','IRE',null FROM DUAL UNION
select 20,'Italy'               ,'Y','IT',null FROM DUAL UNION
select 21,'Latvia'              ,'Y','LAT',null FROM DUAL UNION
select 22,'Lithuania'           ,'Y','LI',null FROM DUAL UNION
select 23,'Luxembourg'          ,'Y','LUX',null FROM DUAL UNION
select 24,'Malta'               ,'Y','MAL',null FROM DUAL UNION
select 25,'Netherlands'         ,'Y','ND',null FROM DUAL UNION
select 26,'Poland'              ,'Y','POL',null FROM DUAL UNION
select 27 ,'Portugal'           ,'Y','POR',null FROM DUAL UNION
select 28,'Romania'             ,'Y','ROM',null FROM DUAL UNION
select 29,'Slovakia'            ,'Y','SLK',null FROM DUAL UNION
select 30,'Slovenia'            ,'Y','SLV',null FROM DUAL UNION
select 31,'Spain'               ,'Y','SP',null FROM DUAL UNION
select 32,'Sweden'              ,'Y','SWE',null FROM DUAL)
SELECT * FROM SOURCE;
--
create table activity
(id number not null
,country_id   number(3)
,R2      number(2)
,num1      number(4)
,num2      number(3)
,vc1       varchar2(10)
,vc_r1     varchar2(20)
,v_pad     varchar2(1000)
)
/
--
-- 10 1M chunks takes much less time than 1 10M chunk 
--due to the cartesion join spilling over to disk

begin
for i in 1..10 loop
  insert into activity
  with d1 as
  (select trunc(dbms_random.value(1,33)) r1,mod(rownum,1000) n1
    ,rpad(chr(65+mod(rownum,24)),10,chr(65+mod(rownum,25))) vc1
  from dual connect by level < 1001),
  d2 as
  (select trunc(dbms_random.value(0,10)) r2,mod(rownum+13,100) n2
    ,dbms_random.string('U',20) vc2
  from dual connect by level < 1001)
  select rownum+(1000000*(i-1)),r1,r2,n1,n2,vc1,vc2, rpad('A',50,'A')
  -- cartesian product
  from d1,d2;
  commit;
end loop;
end;
/
alter table activity add constraint acti_pk primary key (id)
/