-- drop_ch6_demos
-- this drops all the demonstration tables and packages for ch6 of Real World SQL & PL/SQL
--
prompt dropping the demo tables
exec pna_cre.drop_tabs('Y')
drop table ACTIVITY;
drop table COUNTRY;
prompt dropping the three packages PNA_MAINT, PNA_CRE and STR_UTIL
drop package PNA_MAINT;
drop package PNA_CRE;
drop package STR_UTIL;
drop table exec_func_track;
promt finished